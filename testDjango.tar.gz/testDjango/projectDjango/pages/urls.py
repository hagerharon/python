from django.urls import path
from . import views

urlpatterns =[
    path('',views.welcome,name='welcome'),
    path('mg',views.img,name='img'),
    path('add', views.add, name='add')

]
