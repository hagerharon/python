from django.shortcuts import render
from django.http import HttpResponse

def welcome(request):
    #return HttpResponse('hello gogoooooooooo')
    return render(request,'home.html',{'keyname':'alla Akber Noor Creation','size':5576767})
# Create your views here.
def img(request):
    return render(request,'img.html')

def add(request):
    val1 = int(request.POST["num1"])
    val2 = int(request.POST["num2"])
    res = val1 + val2
    return render(request,'add.html',{'result': res})