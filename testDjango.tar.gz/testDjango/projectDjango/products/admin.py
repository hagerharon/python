from django.contrib import admin
from .models import Car,DATTE
admin.site.register(Car)
admin.site.register(DATTE)

# Register your models here.
