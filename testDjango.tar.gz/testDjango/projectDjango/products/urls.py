from django.urls import path
from . import views

urlpatterns =[
    path('',views.allProducts,name='allProducts'),
    path('product',views.detailsProduct,name='detailsProduct'),
]
