from django.shortcuts import render
from . models import Car
def allProducts(request):
    return render(request, 'products/allProducts.html',{'pro':Car.objects.all()})

def detailsProduct(request):
    return render(request, 'products/detailsProduct.html')
# Create your views here.
