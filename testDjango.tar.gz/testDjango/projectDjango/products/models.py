from django.db import models
from datetime import datetime

class Car(models.Model):
    y = [
        ('Egpyt', 'Egpyt'),
        ('China', 'China'),
    ]
    name = models.CharField(max_length=100)
    image = models.ImageField(upload_to='photo_products/%y/%m/%d')
    price = models.DecimalField(max_digits=6,decimal_places=2)
    review = models.TextField(verbose_name='describtion',null=True,blank=True)
    activa = models.BooleanField(default=True)
    catageroy = models.CharField(max_length=50,choices=y,default='Egpyt')

    def __str__(self):
        return (self.name)
    class Meta:
        ordering =['-name']

class DATTE(models.Model):
    name = models.CharField(max_length=50,default='Title of Post')
    DateNow = models.DateTimeField(default=datetime.now, verbose_name='select time')

    def __str__(self):
        return (self.name)

        #verbose_name ='1992-2020'
    # Create your models here.
