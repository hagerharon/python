from django.db import models
class Destnation:
    id: int
    name: str
    image: str
    des: str
    price: int
# Create your models here.
