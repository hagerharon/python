from django.shortcuts import render
from .models import Destnation
def index(request):
    des1 = Destnation()
    des1.name= 'mobil'
    des1.image='destination_4.jpg'
    des1.des= 'new version from oppo 2023'
    des1.price=3300

    des2 = Destnation()
    des2.name= 'mobil'
    des2.image= 'team_2.jpg'
    des2.des= 'new version from oppo 2023'
    des2.price=3000

    des3 = Destnation()
    des3.name= 'mobil'
    des3.des= 'new version from oppo 2023'
    des3.price=3500

    desall = [des1,des2,des3]

    return render(request,'index.html', {'desall': desall})
# Create your views here.
